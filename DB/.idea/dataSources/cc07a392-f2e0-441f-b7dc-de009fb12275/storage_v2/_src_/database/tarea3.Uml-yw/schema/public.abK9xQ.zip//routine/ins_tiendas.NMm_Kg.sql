create function ins_tiendas(i integer)
  returns void
language plpgsql
as $$
declare
    id int;
begin
    id=1;
    while (id<=i) loop
        insert into tiendas values
        (
            id,
            'tienda '||cast(id as varchar(15))
        );
        id=id+1;
    END LOOP;
end
$$;

