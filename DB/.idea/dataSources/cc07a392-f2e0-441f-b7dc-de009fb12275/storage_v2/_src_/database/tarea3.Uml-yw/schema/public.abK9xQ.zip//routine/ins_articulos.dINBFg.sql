create function ins_articulos(i integer)
  returns void
language plpgsql
as $$
declare
    id int;
begin
    id=1;
    while (id<=i) loop
        insert into articulos values
        (
            id,
            'articulo '||cast(id as varchar(15)),
            500 * random()::numeric::money
        );
        id=id+1;
    END LOOP;
end
$$;

