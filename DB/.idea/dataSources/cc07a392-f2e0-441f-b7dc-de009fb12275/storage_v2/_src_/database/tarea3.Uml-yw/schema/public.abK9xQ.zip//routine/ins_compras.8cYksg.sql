create function ins_compras(i integer)
  returns void
language plpgsql
as $$
declare
    id int;
begin
    id=1;
    while (id<=i) loop
        insert into compras values
        (
            id,
            now() - '15 year'::interval,
            5000*random()::numeric::money,
            999999*random()+1,
            499*random()+1
        );
        id=id+1;
    END LOOP;
end
$$;

