create function ins_clientes(i integer)
  returns void
language plpgsql
as $$
declare
    id int;
begin
    id=1;
    while (id<=i) loop
        insert into clientes values
        (
            id,
            'Cliente '||cast(id as varchar(15)),
            now() - '18 year'::interval - ('50 year'::interval * random())
        );
        id=id+1;
    END LOOP;
end
$$;

