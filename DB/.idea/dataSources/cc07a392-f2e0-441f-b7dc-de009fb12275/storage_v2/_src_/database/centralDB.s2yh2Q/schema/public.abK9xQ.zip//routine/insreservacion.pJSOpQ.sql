create function insreservacion(p_idusuario integer, p_idsede integer, p_costo integer, p_idservicio integer, p_cantidad integer)
  returns void
language plpgsql
as $$
DECLARE
	p_montoTotal int;
	currentID int;
	p_fecha date;

BEGIN
	--hacer cases para todas las sedes cuando se tengan las bd
	CASE p_idSede
	--if sede = x : dbname=?--
		WHEN 2 THEN --nodoII
			--consulta dist
			p_montoTotal=p_costo*p_cantidad;
			p_fecha = cast((now() + '1 year'::interval * random()) as date);
			currentID = cast((SELECT currval('reservas_idReserva_seq')) as integer)+1;--para saber por cuál índice va la tabla (SERIAL TYPE)
			INSERT INTO reservas(idSede, idUsuario, montoTotal, fecha) VALUES (p_idSede, p_idUsuario, p_montoTotal, p_fecha);

			PERFORM dblink('host=localhost user=postgres password=aniram dbname=nodeII', --aquí va la sede
				    FORMAT('INSERT INTO servicios_reservas VALUES
				    (%s,%s,%s,%s)',p_idServicio,currentID,p_cantidad, p_costo));
		WHEN 3 THEN --nodoIII

			p_montoTotal=p_costo*p_cantidad;
			p_fecha = cast((now() + '1 year'::interval * random()) as date); --inserta de la fecha de hoy en adelante
			currentID = cast((SELECT currval('reservas_idReserva_seq')) as integer)+1;
			PERFORM dblink('host=localhost user=postgres password=aniram dbname=nodeIII', --aquí va la sede
				    FORMAT('INSERT INTO servicios_reservas VALUES
				    (%s,%s,%s,%s)',p_idServicio,currentID,p_cantidad, p_costo));
			INSERT INTO reservas(idSede, idUsuario, montoTotal, fecha) VALUES (p_idSede, p_idUsuario, p_montoTotal, p_fecha);
		--WHEN X THEN -- INSERT INTO DATABASE REQUIRED.
	END CASE;

END;
$$;

