create function insreservacionn(i integer)
  returns void
language plpgsql
as $$
DECLARE
	p_idUsuario int;
	p_idSede int; --pueden variar las sedes entonces genérico
	p_montoTotal int;
	p_fecha date;
	p_costo int;
	p_idServicio int;
	p_cantidad int;
	currentID int;
BEGIN
	WHILE (i>1) LOOP
		p_idUsuario = (select(floor(random() * (select count(*) from usuarios) + 1)::int));
		p_idSede = 2; --x el momento solo el nodo 2 está habilitado
		p_costo = (select( floor ( random() * 1000 + 35)::int));
		p_fecha = cast((now() + '1 year'::interval * random()) as date);
		p_idServicio = (select ( floor( random() * (select * from dblink ('host=localhost user=postgres password=aniram dbname=nodeII',
				'select count(*) from servicios') as cant_reg(cant int))+1)::int));
		p_cantidad = (select ( floor (random()* 6 + 2)::int));
		currentID = cast((SELECT currval('reservas_idReserva_seq')) as integer)+1;
		p_montoTotal = p_costo * p_cantidad;
		INSERT INTO reservas(idSede, idUsuario, montoTotal, fecha) VALUES (p_idSede, p_idUsuario, p_montoTotal, p_fecha);
		PERFORM dblink('host=localhost user=postgres password=aniram dbname=nodeII', --aquí va la sede
			FORMAT('INSERT INTO servicios_reservas VALUES (%s,%s,%s,%s)',
			p_idServicio,currentID,p_cantidad, p_costo));
		i = i-1;
	END LOOP;
END;
$$;

