create function bytea_import(p_path text, OUT p_result bytea)
  returns bytea
language plpgsql
as $$
DECLARE
  l_oid oid;
BEGIN
  SELECT lo_import(p_path) INTO l_oid;
  SELECT lo_get(l_oid) INTO p_result;
  PERFORM lo_unlink(l_oid);
END;
$$;

