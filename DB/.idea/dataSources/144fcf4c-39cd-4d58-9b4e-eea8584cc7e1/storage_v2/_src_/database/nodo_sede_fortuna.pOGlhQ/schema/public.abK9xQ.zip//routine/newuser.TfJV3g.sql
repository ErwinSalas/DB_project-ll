create function newuser(idusuario integer, email character varying, psswrd character varying, nombre character varying, apellido1 character varying, apellido2 character varying)
  returns record
language sql
as $$
INSERT INTO usuarios VALUES (idUsuario, email, psswrd);
	--INSERT centralDB
	SELECT dblink('host=localhost user=postgres password=postgres dbname=centraldb',
		    FORMAT('INSERT INTO usuarios VALUES 
		    (%s,''%s'',''%s'',''%s'')',idUsuario,nombre,apellido1,
			apellido2));
$$;

