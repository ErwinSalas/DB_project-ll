create function insreservacion(p_idreserva integer, p_idusuario integer, p_idsede integer, p_fecha date, p_idservicio integer, p_cantidad integer)
  returns void
language plpgsql
as $$
DECLARE
	p_montoTotal int; 
	costo int;

BEGIN
	--hacer cases para todas las sedes cuando se tengan las bd
	CASE p_idSede
	--if sede = x : dbname=?--
		WHEN 2 THEN --nodoII
			costo = (SELECT s.costo FROM (SELECT * FROM dblink('host=localhost user=postgres password=aniram dbname=nodeII',
					FORMAT('SELECT costo FROM servicios where idServicio = %s', p_idServicio))AS servicios(costo int))AS s);
			p_montoTotal=costo*p_cantidad;
			INSERT INTO reservas(idReserva, idSede, idUsuario, montoTotal, fecha) VALUES (p_idReserva, p_idSede, p_idUsuario, p_montoTotal, p_fecha);
			PERFORM dblink('host=localhost user=postgres password=aniram dbname=nodeII', --aquí va la sede
				    FORMAT('INSERT INTO servicios_reservas VALUES 
				    (%s,%s,%s)',p_idServicio,p_idReserva,p_cantidad));
		WHEN 3 THEN --nodoIII
			costo = (SELECT s.costo FROM (SELECT * FROM dblink('host=localhost user=postgres password=aniram dbname=nodeIII',
					FORMAT('SELECT costo FROM servicios where idServicio = %s', p_idServicio))AS servicios(costo int))AS s);
			p_montoTotal=costo*p_cantidad;
			INSERT INTO reservas(idReserva, idSede, idUsuario, montoTotal, fecha) VALUES (p_idReserva, p_idSede, p_idUsuario, p_montoTotal, p_fecha);
			PERFORM dblink('host=localhost user=postgres password=aniram dbname=nodeIII', --aquí va la sede
				    FORMAT('INSERT INTO servicios_reservas VALUES 
				    (%s,%s,%s)',p_idServicio,p_idReserva,p_cantidad));
		--WHEN X THEN -- INSERT INTO DATABASE REQUIRED.
	END CASE; 
	
END;
$$;

